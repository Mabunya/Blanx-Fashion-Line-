/* HOME — one product grid with category filters */
const homeCategories = ["caps", "sneakers", "hoodies", "tees", "jackets"];

function renderProductCard(p) {
  return `
    <article class="product" onclick="openProduct('${p.id}')">
      <div class="product-image">
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ""}
        ${productVisual(p)}
      </div>
      <div class="product-info">
        <div class="product-name">${p.name}</div>
        <div class="product-price">${money(p.price)}</div>
        <div class="product-colors">${p.colors.map(c => `<span class="color-dot" style="background:${c}"></span>`).join("")}</div>
      </div>
    </article>`;
}

function renderHomeGrid(category = "all") {
  homeCategories.forEach(sectionCategory => {
    const grid = document.getElementById(`${sectionCategory}Grid`);
    if (!grid) return;
    const list = PRODUCTS.filter(product => {
      const productCategory = String(product.category || "").toLowerCase();
      return productCategory === sectionCategory && (category === "all" || productCategory === category);
    });
    grid.innerHTML = list.map(renderProductCard).join("");
  });
}

function setupCategoryFilters() {
  document.querySelectorAll(".shop-categories [data-filter]").forEach(button => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".shop-categories [data-filter]").forEach(item => item.classList.remove("active"));
      button.classList.add("active");
      renderHomeGrid(button.dataset.filter);
    });
  });
}

function renderLookbook() {
  const grid = document.getElementById("lookbookGrid");
  if (!grid) return;

  const looks = [
    { title: "Thursday meetings, no compromise.", products: ["cap-001", "hoodie-001", "sneaker-001"] },
    { title: "Off the clock, still put together.", products: ["tee-001", "jacket-001"] },
    { title: "Late one, early call.", products: ["hoodie-003", "jacket-003", "sneaker-006"] }
  ];

  grid.innerHTML = looks.map(look => {
    const pieces = look.products.map(id => PRODUCTS.find(product => product.id === id)).filter(Boolean);
    return `
      <article class="look-card">
        <div class="look-card-image" style="--look-piece-count:${pieces.length}">
          ${pieces.map(product => `<a class="look-piece" href="${BLANX.base}pages/product.html?id=${product.id}" aria-label="Shop ${product.name}">${productVisual(product)}</a>`).join("")}
        </div>
        <div class="look-card-copy">
          <h3>${look.title}</h3>
          <p class="look-shop-label">Shop this look</p>
          <div class="look-card-links" aria-label="Shop pieces in this look">
            ${pieces.map(product => `<a href="${BLANX.base}pages/product.html?id=${product.id}">${product.name}</a>`).join("")}
          </div>
        </div>
      </article>`;
  }).join("");
}

function setupPageMotion() {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("is-visible");
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });

  const targets = document.querySelectorAll(
    ".section-title, .category-head, .product, .look-card, .about-copy p, .footer-cta-inner, .service-item, .footer-column"
  );
  targets.forEach((target, index) => {
    const position = target.matches(".product, .look-card, .service-item, .footer-column")
      ? [...target.parentElement.children].indexOf(target)
      : index % 4;
    target.style.setProperty("--reveal-delay", `${Math.min(position, 4) * 85}ms`);
    target.classList.add("scroll-reveal");
    observer.observe(target);
  });

  document.body.classList.add("motion-ready");
}

document.addEventListener("DOMContentLoaded", async () => {
  await loadProducts();
  renderHomeGrid();
  renderLookbook();
  setupCategoryFilters();
  setupPageMotion();
});

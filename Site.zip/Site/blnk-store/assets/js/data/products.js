/* --- STATIC FALLBACK DATA --- */
const STATIC_PRODUCTS = [
  /* ============ CAPS — real photos ============ */
  {
    id: "cap-walm-vany",
    name: "WALM VANY Trucker",
    price: 1500,
    category: "caps",
    badge: "NEW",
    desc: "Embroidered trucker cap. Cream front panel, brown mesh back, pink lip embroidery. 'What comes out of your mouth comes into your life.'",
    colors: ["#f0e6d2", "#5a3a2e", "#e91e63"],
    sizes: ["ONE SIZE"],
    icon: "cap",
    imageUrl: "images/cap-walm-vany.jpg",
    images: [
      "images/cap-walm-vany.jpg",
      "images/cap-walm-vany-2.jpg"
    ]
  },
  {
    id: "cap-002",
    name: "BLNK Dad Cap",
    price: 1000,
    category: "caps",
    desc: "Unstructured cotton twill, curved brim, soft-washed finish.",
    colors: ["#2a2a2a", "#c8c2b4", "#4a5a3a"],
    sizes: ["ONE SIZE"],
    icon: "cap",
    imageUrl: null,
    images: []
  },
  {
    id: "cap-003",
    name: "Trucker Snap",
    price: 1400,
    category: "caps",
    desc: "Mesh back, foam front, snap closure. Everyday trucker.",
    colors: ["#111111", "#d4cec2"],
    sizes: ["ONE SIZE"],
    icon: "cap",
    imageUrl: null,
    images: []
  },

  /* ============ SNEAKERS ============ */
  {
    id: "sneaker-001", name: "Air Force 1", price: 2000, category: "sneakers", badge: "HOT",
    desc: "Classic silhouette, full-grain leather, Air cushioning.",
    colors: ["#ffffff", "#111111"], sizes: ["40","41","42","43","44","45"],
    icon: "sneaker", imageUrl: null, images: []
  },
  {
    id: "sneaker-002", name: "Jordan 4 Retro", price: 3500, category: "sneakers",
    desc: "Iconic flight silhouette with visible Air unit and premium suede overlays.",
    colors: ["#111111", "#5a5a5a"], sizes: ["40","41","42","43","44","45"],
    icon: "sneaker", imageUrl: null, images: []
  },
  {
    id: "sneaker-003", name: "Nike TN", price: 3600, category: "sneakers",
    desc: "Tuned Air cushioning, aggressive tread, statement colourways.",
    colors: ["#111111", "#e2722b"], sizes: ["41","42","43","44"],
    icon: "sneaker", imageUrl: null, images: []
  },
  {
    id: "sneaker-004", name: "Air Max 97", price: 3300, category: "sneakers",
    desc: "Full-length Air, ripple design, water-ripple inspired upper.",
    colors: ["#e8e3d7", "#8a8a8a", "#4a5a3a"], sizes: ["41","42","43","44"],
    icon: "sneaker", imageUrl: null, images: []
  },

  /* ============ HOODIES ============ */
  {
    id: "hoodie-001", name: "Zero Zip Hoodie", price: 3200, category: "hoodies", badge: "NEW",
    desc: "Heavyweight fleece, full-zip front, tonal hardware.",
    colors: ["#111111", "#2a2a2a", "#e6e2d8"], sizes: ["S","M","L","XL"],
    icon: "hoodie", imageUrl: null, images: []
  },
  {
    id: "hoodie-002", name: "Raw Pullover", price: 2800, category: "hoodies",
    desc: "Mid-weight pullover hoodie. Kangaroo pocket, raw edges, no logo.",
    colors: ["#111111", "#8a8a8a", "#c8c2b4"], sizes: ["S","M","L","XL"],
    icon: "hoodie", imageUrl: null, images: []
  },
  {
    id: "hoodie-003", name: "Block Hood", price: 3400, category: "hoodies",
    desc: "Oversized fit, dropped shoulders, ribbed cuffs and hem.",
    colors: ["#111111", "#d4cec2"], sizes: ["M","L","XL"],
    icon: "hoodie", imageUrl: null, images: []
  },

  /* ============ TEES ============ */
  {
    id: "tee-001", name: "Raw Tee", price: 1500, category: "tees",
    desc: "260gsm combed cotton, boxy fit, garment-dyed.",
    colors: ["#111111", "#ffffff", "#c8c2b4"], sizes: ["S","M","L","XL"],
    icon: "tee", imageUrl: null, images: []
  },
  {
    id: "tee-002", name: "Blank Tee", price: 1400, category: "tees",
    desc: "Everyday essential. Soft-washed, no logo, no rules.",
    colors: ["#ffffff", "#111111", "#8a8a8a"], sizes: ["S","M","L","XL"],
    icon: "tee", imageUrl: null, images: []
  },

  /* ============ JACKETS ============ */
  {
    id: "jacket-001", name: "Block Jacket", price: 5500, category: "jackets",
    desc: "Technical shell, water-repellent finish, taped seams.",
    colors: ["#111111", "#1a3a5a"], sizes: ["S","M","L","XL"],
    icon: "jacket", imageUrl: null, images: []
  },
  {
    id: "jacket-002", name: "Utility Overshirt", price: 4200, category: "jackets",
    desc: "Cotton-twill overshirt. Chest pockets, boxy cut.",
    colors: ["#4a5a3a", "#111111", "#c8c2b4"], sizes: ["S","M","L","XL"],
    icon: "jacket", imageUrl: null, images: []
  }
];/* --- STATIC FALLBACK DATA --- */
const STATIC_PRODUCTS = [
  /* ============ CAPS — real photos ============ */
  {
    id: "cap-walm-vany",
    name: "WALM VANY Trucker",
    price: 1500,
    category: "caps",
    badge: "NEW",
    desc: "Embroidered trucker cap. Cream front panel, brown mesh back, pink lip embroidery. 'What comes out of your mouth comes into your life.'",
    colors: ["#f0e6d2", "#5a3a2e", "#e91e63"],
    sizes: ["ONE SIZE"],
    icon: "cap",
    imageUrl: "images/cap-walm-vany.jpg",
    images: [
      "images/cap-walm-vany.jpg",
      "images/cap-walm-vany-2.jpg"
    ]
  },
  {
    id: "cap-002",
    name: "BLNK Dad Cap",
    price: 1000,
    category: "caps",
    desc: "Unstructured cotton twill, curved brim, soft-washed finish.",
    colors: ["#2a2a2a", "#c8c2b4", "#4a5a3a"],
    sizes: ["ONE SIZE"],
    icon: "cap",
    imageUrl: null,
    images: []
  },
  {
    id: "cap-003",
    name: "Trucker Snap",
    price: 1400,
    category: "caps",
    desc: "Mesh back, foam front, snap closure. Everyday trucker.",
    colors: ["#111111", "#d4cec2"],
    sizes: ["ONE SIZE"],
    icon: "cap",
    imageUrl: null,
    images: []
  },

  /* ============ SNEAKERS ============ */
  {
    id: "sneaker-001", name: "Air Force 1", price: 2000, category: "sneakers", badge: "HOT",
    desc: "Classic silhouette, full-grain leather, Air cushioning.",
    colors: ["#ffffff", "#111111"], sizes: ["40","41","42","43","44","45"],
    icon: "sneaker", imageUrl: null, images: []
  },
  {
    id: "sneaker-002", name: "Jordan 4 Retro", price: 3500, category: "sneakers",
    desc: "Iconic flight silhouette with visible Air unit and premium suede overlays.",
    colors: ["#111111", "#5a5a5a"], sizes: ["40","41","42","43","44","45"],
    icon: "sneaker", imageUrl: null, images: []
  },
  {
    id: "sneaker-003", name: "Nike TN", price: 3600, category: "sneakers",
    desc: "Tuned Air cushioning, aggressive tread, statement colourways.",
    colors: ["#111111", "#e2722b"], sizes: ["41","42","43","44"],
    icon: "sneaker", imageUrl: null, images: []
  },
  {
    id: "sneaker-004", name: "Air Max 97", price: 3300, category: "sneakers",
    desc: "Full-length Air, ripple design, water-ripple inspired upper.",
    colors: ["#e8e3d7", "#8a8a8a", "#4a5a3a"], sizes: ["41","42","43","44"],
    icon: "sneaker", imageUrl: null, images: []
  },

  /* ============ HOODIES ============ */
  {
    id: "hoodie-001", name: "Zero Zip Hoodie", price: 3200, category: "hoodies", badge: "NEW",
    desc: "Heavyweight fleece, full-zip front, tonal hardware.",
    colors: ["#111111", "#2a2a2a", "#e6e2d8"], sizes: ["S","M","L","XL"],
    icon: "hoodie", imageUrl: null, images: []
  },
  {
    id: "hoodie-002", name: "Raw Pullover", price: 2800, category: "hoodies",
    desc: "Mid-weight pullover hoodie. Kangaroo pocket, raw edges, no logo.",
    colors: ["#111111", "#8a8a8a", "#c8c2b4"], sizes: ["S","M","L","XL"],
    icon: "hoodie", imageUrl: null, images: []
  },
  {
    id: "hoodie-003", name: "Block Hood", price: 3400, category: "hoodies",
    desc: "Oversized fit, dropped shoulders, ribbed cuffs and hem.",
    colors: ["#111111", "#d4cec2"], sizes: ["M","L","XL"],
    icon: "hoodie", imageUrl: null, images: []
  },

  /* ============ TEES ============ */
  {
    id: "tee-001", name: "Raw Tee", price: 1500, category: "tees",
    desc: "260gsm combed cotton, boxy fit, garment-dyed.",
    colors: ["#111111", "#ffffff", "#c8c2b4"], sizes: ["S","M","L","XL"],
    icon: "tee", imageUrl: null, images: []
  },
  {
    id: "tee-002", name: "Blank Tee", price: 1400, category: "tees",
    desc: "Everyday essential. Soft-washed, no logo, no rules.",
    colors: ["#ffffff", "#111111", "#8a8a8a"], sizes: ["S","M","L","XL"],
    icon: "tee", imageUrl: null, images: []
  },

  /* ============ JACKETS ============ */
  {
    id: "jacket-001", name: "Block Jacket", price: 5500, category: "jackets",
    desc: "Technical shell, water-repellent finish, taped seams.",
    colors: ["#111111", "#1a3a5a"], sizes: ["S","M","L","XL"],
    icon: "jacket", imageUrl: null, images: []
  },
  {
    id: "jacket-002", name: "Utility Overshirt", price: 4200, category: "jackets",
    desc: "Cotton-twill overshirt. Chest pockets, boxy cut.",
    colors: ["#4a5a3a", "#111111", "#c8c2b4"], sizes: ["S","M","L","XL"],
    icon: "jacket", imageUrl: null, images: []
  }
];
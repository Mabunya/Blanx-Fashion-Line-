/* ============================================================
   UI — shared layout (header/footer), cart drawer, product modal,
   search. Injected on every page so the HTML files stay small.
   ============================================================ */
let activeProduct = null, selectedColor = null, selectedSize = null;

/* ---------- Layout ---------- */
function layoutTop() {
  const b = BLNK.base;
  return `
  <div class="announce"><span>GET 10% OFF — USE CODE <strong>BLNK10</strong> AT CHECKOUT</span></div>
  <header class="site-header">
    <nav class="nav nav-left" id="mainNav">
      <a href="${b}index.html">HOME</a>
      <a href="${b}index.html#shop">SHOP</a>
      <a href="${b}index.html#lookbook">LOOKBOOK</a>
      <a href="${b}index.html#about">ABOUT</a>
      <a href="${b}index.html#contact">CONTACT</a>
    </nav>
    <a href="${b}index.html" class="logo">BLNK</a>
    <div class="header-actions">
      <button class="icon-btn" aria-label="Search" onclick="toggleSearch()">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/></svg>
      </button>
      <button class="icon-btn cart-btn" aria-label="Cart" onclick="openCart()">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 6h16l-1.5 12h-13z"/><path d="M9 6V4a3 3 0 0 1 6 0v2"/></svg>
        <span class="cart-count">0</span>
      </button>
    </div>
    <button class="menu-toggle" aria-label="Menu" onclick="document.getElementById('mainNav').classList.toggle('open')"><span></span><span></span></button>
  </header>`;
}

function layoutBottom() {
  const b = BLNK.base;
  return `
  <footer class="site-footer" id="contact">
    <div class="footer-inner">
      <div>
        <div class="logo">BLNK</div>
        <p>Clean pieces. No noise.</p>
      </div>
      <div>
        <h4>SHOP</h4>
        <a href="${b}index.html#shop">All products</a>
        <a href="${b}pages/cart.html">Cart</a>
      </div>
      <div>
        <h4>CONTACT</h4>
        <a href="https://wa.me/${WHATSAPP_NUMBER}" target="_blank" rel="noopener">WhatsApp us</a>
      </div>
    </div>
    <div class="footer-base">© ${new Date().getFullYear()} BLNK. All rights reserved.</div>
  </footer>

  <div class="search-overlay" id="searchOverlay">
    <div class="search-box">
      <button class="cart-close" onclick="toggleSearch()" aria-label="Close search">×</button>
      <input id="searchInput" type="text" placeholder="Search products…" oninput="handleSearch(this.value)" autocomplete="off" />
      <div id="searchResults"></div>
    </div>
  </div>

  <div class="cart-overlay" id="cartOverlay" onclick="closeCart()"></div>
  <aside class="cart-drawer" id="cartDrawer" aria-label="Cart">
    <div class="cart-header"><h3>YOUR CART</h3><button class="cart-close" onclick="closeCart()" aria-label="Close cart">×</button></div>
    <div class="cart-items" id="cartItems"></div>
    <div class="cart-empty" id="cartEmpty">
      <p>Your cart is empty.</p>
      <button class="btn-outline dark" onclick="closeCart()">CONTINUE SHOPPING</button>
    </div>
    <div class="cart-footer" id="cartFooter" style="display:none;">
      <div class="cart-row"><span>Subtotal</span><span id="cartSubtotal">KES 0</span></div>
      <div class="cart-row small"><span>Delivery calculated at checkout</span></div>
      <a href="${b}pages/checkout.html" class="btn-checkout">PROCEED TO CHECKOUT</a>
      <button class="btn-checkout wa" onclick="checkoutWhatsApp()">QUICK ORDER ON WHATSAPP</button>
      <p class="cart-note">You'll be redirected to WhatsApp with your order details.</p>
    </div>
  </aside>

  <div class="modal-overlay" id="modalOverlay" onclick="closeModal(event)">
    <div class="modal" onclick="event.stopPropagation()">
      <button class="modal-close" onclick="closeModal(event)" aria-label="Close">×</button>
      <div class="modal-content" id="modalContent"></div>
    </div>
  </div>`;
}

function injectLayout() {
  if (document.getElementById("cartDrawer")) return;
  document.body.insertAdjacentHTML("afterbegin", layoutTop());
  document.body.insertAdjacentHTML("beforeend", layoutBottom());
}

/* ---------- Cart drawer ---------- */
function renderCartDrawer() {
  const items = document.getElementById("cartItems");
  if (!items) return;
  const empty = document.getElementById("cartEmpty");
  const footer = document.getElementById("cartFooter");

  if (!cart.length) { items.innerHTML = ""; empty.style.display = "flex"; footer.style.display = "none"; return; }
  empty.style.display = "none"; footer.style.display = "block";

  items.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-item-img">${item.imageUrl ? productVisual(item) : iconSvg(item.icon, item.color)}</div>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-meta">${swatch(item.color)} ${item.size}</div>
        <div class="cart-qty">
          <button onclick="changeQty('${item.key}', -1)">−</button><span>${item.qty}</span><button onclick="changeQty('${item.key}', 1)">+</button>
        </div>
        <div class="cart-item-price">${money(item.price * item.qty)}</div>
      </div>
      <button class="cart-item-remove" onclick="removeFromCart('${item.key}')">Remove</button>
    </div>`).join("");
  document.getElementById("cartSubtotal").textContent = money(cartTotal());
}

function openCart() {
  document.getElementById("cartDrawer")?.classList.add("open");
  document.getElementById("cartOverlay")?.classList.add("open");
  document.body.style.overflow = "hidden";
}
function closeCart() {
  document.getElementById("cartDrawer")?.classList.remove("open");
  document.getElementById("cartOverlay")?.classList.remove("open");
  document.body.style.overflow = "";
}

/* ---------- Product quick-view modal ---------- */
function openProduct(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  activeProduct = p;
  selectedColor = p.colors[0];
  const defaultSize = Math.min(1, p.sizes.length - 1);
  selectedSize = p.sizes[defaultSize];

  document.getElementById("modalContent").innerHTML = `
    <div class="modal-image">${productVisual(p, selectedColor)}</div>
    <div class="modal-info">
      <span class="modal-cat">${p.category.toUpperCase()}</span>
      <h2 class="modal-name">${p.name}</h2>
      <div class="modal-price">${money(p.price)}</div>
      <p class="modal-desc">${p.desc}</p>
      <div class="modal-label">COLOUR</div>
      <div class="modal-colors">${p.colors.map((c, i) =>
        `<button class="modal-color ${i === 0 ? "active" : ""}" style="background:${c}" onclick="pickColor('${c}', this)"></button>`).join("")}</div>
      <div class="modal-label">SIZE</div>
      <div class="modal-sizes">${p.sizes.map((s, i) =>
        `<button class="modal-size ${i === defaultSize ? "active" : ""}" onclick="pickSize('${s}', this)">${s}</button>`).join("")}</div>
      <div class="modal-actions">
        <button class="btn-add" onclick="addToCartFromModal()">ADD TO CART</button>
        <a href="${BLNK.base}pages/product.html?id=${p.id}" class="btn-wa-modal">VIEW FULL DETAILS</a>
      </div>
    </div>`;
  document.getElementById("modalOverlay").classList.add("open");
  document.body.style.overflow = "hidden";
}

function pickColor(color, btn) {
  selectedColor = color;
  document.querySelectorAll(".modal-color").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  const img = document.querySelector(".modal-image");
  if (img && activeProduct) img.innerHTML = productVisual(activeProduct, color);
}
function pickSize(size, btn) {
  selectedSize = size;
  document.querySelectorAll(".modal-size").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
}
function closeModal(e) {
  if (e) e.stopPropagation();
  document.getElementById("modalOverlay")?.classList.remove("open");
  document.body.style.overflow = "";
}
function addToCartFromModal() {
  if (!activeProduct) return;
  addToCart({ id: activeProduct.id, name: activeProduct.name, price: activeProduct.price,
              color: selectedColor, size: selectedSize, icon: activeProduct.icon,
              imageUrl: activeProduct.imageUrl || null });
  closeModal();
}

/* ---------- Search ---------- */
function toggleSearch() {
  const el = document.getElementById("searchOverlay");
  el.classList.toggle("open");
  if (el.classList.contains("open")) setTimeout(() => document.getElementById("searchInput").focus(), 100);
  else { document.getElementById("searchInput").value = ""; document.getElementById("searchResults").innerHTML = ""; }
}

function handleSearch(q) {
  const out = document.getElementById("searchResults");
  const query = (q || "").trim().toLowerCase();
  if (!query) { out.innerHTML = ""; return; }
  const matches = PRODUCTS.filter(p => p.name.toLowerCase().includes(query) || p.category.toLowerCase().includes(query));
  out.innerHTML = matches.length
    ? matches.map(p => `<div class="search-result-item" onclick="goToProduct('${p.id}')"><span>${p.name}</span><span class="price">${money(p.price)}</span></div>`).join("")
    : `<p class="search-none">No results for "${q}"</p>`;
}

/* On the home page open the quick-view, elsewhere go to the product page */
function goToProduct(id) {
  toggleSearch();
  if (document.getElementById("productGrid")) openProduct(id);
  else location.href = `${BLNK.base}pages/product.html?id=${id}`;
}

/* ---------- Init ---------- */
document.addEventListener("DOMContentLoaded", () => {
  injectLayout();
  syncCartUI();
  const header = document.querySelector(".site-header");
  window.addEventListener("scroll", () => header.classList.toggle("scrolled", window.scrollY > 10));
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    closeCart(); closeModal();
    if (document.getElementById("searchOverlay").classList.contains("open")) toggleSearch();
  });
});

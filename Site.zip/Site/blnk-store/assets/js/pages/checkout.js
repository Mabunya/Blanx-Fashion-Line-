/* CHECKOUT PAGE — pages/checkout.html (M-Pesa STK push or WhatsApp) */
let pollingTimer = null;

function renderCheckoutSummary() {
  const box = document.getElementById("checkoutItems");
  if (!cart.length) box.innerHTML = `<p class="muted-note">Your cart is empty.</p>`;
  else box.innerHTML = cart.map(item => `
    <div class="summary-item">
      <div class="summary-item-img">${item.imageUrl ? productVisual(item) : iconSvg(item.icon, item.color)}</div>
      <div class="summary-item-info">
        <div class="summary-item-name">${item.name}</div>
        <div class="summary-item-meta">${item.size} · ${swatch(item.color)} · Qty ${item.qty}</div>
      </div>
      <div class="summary-item-price">${money(item.price * item.qty)}</div>
    </div>`).join("");
  document.getElementById("checkoutSubtotal").textContent = money(cartTotal());
  document.getElementById("checkoutTotal").textContent = money(cartTotal());
}

function selectPayment(el) {
  document.querySelectorAll(".payment-option").forEach(o => o.classList.remove("selected"));
  el.classList.add("selected");
  el.querySelector("input").checked = true;
}

const generateOrderId = () => `BLNK-${Date.now()}-${Math.floor(Math.random() * 9000 + 1000)}`;

function getCustomer() {
  const v = id => document.getElementById(id).value.trim();
  return { firstName: v("firstName"), lastName: v("lastName"), phone: v("phone"),
           email: v("email"), location: v("location"), notes: v("notes") };
}

function buildWhatsAppMessage(orderId, c, payment, receipt) {
  let msg = "🛒 *NEW ORDER — BLNK*\n\n";
  if (orderId) msg += `*Order:* ${orderId}\n\n`;
  msg += "*Items:*\n";
  cart.forEach((item, i) => {
    msg += `${i + 1}. ${item.name}\n   ${item.size} | ${item.color} | Qty ${item.qty}\n   ${money(item.price * item.qty)}\n\n`;
  });
  msg += `*Subtotal:* ${money(cartTotal())}\n\n*Customer:*\n`;
  msg += `Name: ${c.firstName} ${c.lastName}\nPhone: ${c.phone}\n`;
  if (c.email) msg += `Email: ${c.email}\n`;
  msg += `Delivery: ${c.location}\n`;
  if (c.notes) msg += `Notes: ${c.notes}\n`;
  msg += `Payment: ${payment}\n`;
  if (receipt) msg += `\n✅ *M-Pesa receipt:* ${receipt}\n*Paid:* ${money(cartTotal())}\n`;
  return msg;
}

const openWhatsApp = msg => window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`, "_blank");

function showStatus(title, text, kind) {
  const el = document.getElementById("paymentStatus");
  el.className = `payment-status ${kind || ""}`; el.style.display = "block";
  el.innerHTML = `<strong>${title}</strong><span>${text}</span>`;
}

function startPolling(orderId, phone, customer) {
  let attempts = 0;
  const MAX = 30; // 30 × 3s = 90s
  clearInterval(pollingTimer);
  pollingTimer = setInterval(async () => {
    attempts++;
    try {
      const res = await fetch(`/api/mpesa/status?orderId=${encodeURIComponent(orderId)}`);
      const data = await res.json();

      if (data.status === "paid") {
        clearInterval(pollingTimer);
        showStatus("✅ PAYMENT RECEIVED", `M-Pesa receipt: ${data.receipt}. Sending you to WhatsApp…`, "success");
        setTimeout(() => {
          openWhatsApp(buildWhatsAppMessage(orderId, customer, "M-Pesa (paid)", data.receipt));
          clearCart();
        }, 1500);
        return;
      }
      if (data.status === "failed") {
        clearInterval(pollingTimer);
        showStatus("❌ PAYMENT FAILED", "You cancelled or the payment failed. Try again or use WhatsApp.", "error");
        return;
      }
      showStatus("⏳ WAITING FOR M-PESA", `Check your phone (${phone}) and enter your M-Pesa PIN. (${attempts}/${MAX})`);
    } catch (err) { console.warn("poll error", err); }

    if (attempts >= MAX) {
      clearInterval(pollingTimer);
      showStatus("⏱ TIMED OUT", "We didn't receive confirmation. Pay again or message us on WhatsApp.", "error");
    }
  }, 3000);
}

async function handleMpesaPayment(customer) {
  const orderId = generateOrderId();
  showStatus("⏳ INITIATING PAYMENT", "Sending M-Pesa prompt to your phone…");
  try {
    const res = await fetch("/api/mpesa/stkpush", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        phone: customer.phone, amount: cartTotal(), orderId, customer,
        items: cart.map(i => ({ id: i.id, name: i.name, qty: i.qty, size: i.size, color: i.color, price: i.price }))
      })
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      showStatus("❌ COULD NOT SEND PROMPT", data.error || "Try again, or choose Cash on Delivery.", "error");
      return;
    }
    showStatus("📲 M-PESA PROMPT SENT", `Check your phone (${customer.phone}) and enter your PIN.`);
    startPolling(orderId, customer.phone, customer);
  } catch (err) {
    console.error(err);
    showStatus("❌ NETWORK ERROR", "Could not reach the payment server. Try again.", "error");
  }
}

async function submitCheckout(e) {
  e.preventDefault();
  if (!cart.length) { alert("Your cart is empty. Add something first."); return; }

  const customer = getCustomer();
  const payment = document.querySelector('input[name="payment"]:checked').value;

  if (payment === "M-Pesa") await handleMpesaPayment(customer);
  else openWhatsApp(buildWhatsAppMessage(generateOrderId(), customer, payment, null));
}

document.addEventListener("DOMContentLoaded", renderCheckoutSummary);

  // Gallery images — use real photos if available, else fall back to colour SVGs
  const galleryItems = (p.images && p.images.length)
    ? p.images.map((src, i) => ({ type: "img", src, i }))
    : p.colors.map((c, i) => ({ type: "svg", color: c, i }));

  const mainVisual = galleryItems[0].type === "img"
    ? `<img src="${galleryItems[0].src}" alt="${p.name}">`
    : iconSvg(p.icon, galleryItems[0].color);

  container.innerHTML = `
    <div class="gallery">
      <div class="gallery-main" id="galleryMain">${mainVisual}</div>
      <div class="gallery-thumbs">
        ${galleryItems.map((g, i) => `
          <div class="gallery-thumb ${i === 0 ? "active" : ""}"
               onclick="selectGalleryItem(${i}, this)">
            ${g.type === "img"
              ? `<img src="${g.src}" alt="">`
              : iconSvg(p.icon, g.color)}
          </div>
        `).join("")}
      </div>
    </div>

    <div class="detail-info">
      <div class="detail-cat">${p.category.toUpperCase()}</div>
      <h1 class="detail-name">${p.name}</h1>
      <div class="detail-price">KES ${p.price.toLocaleString()}</div>
      <p class="detail-desc">${p.desc}</p>

      <div class="detail-label">COLOUR</div>
      <div class="detail-colors">
        ${p.colors.map((c, i) => `
          <button class="detail-color ${i === 0 ? "active" : ""}"
                  style="background:${c}"
                  onclick="selectColor('${c}', this)"></button>
        `).join("")}
      </div>

      <div class="detail-label">SIZE</div>
      <div class="detail-sizes">
        ${p.sizes.map((s, i) => `
          <button class="detail-size ${i === Math.min(1, p.sizes.length - 1) ? "active" : ""}"
                  onclick="selectSize('${s}', this)">${s}</button>
        `).join("")}
      </div>

      <div class="detail-actions">
        <button class="btn-add" onclick="addCurrentToCart()">ADD TO CART</button>
        <button class="btn-wa-modal" onclick="askCurrentOnWhatsApp()">ASK ON WHATSAPP</button>
      </div>

      <div class="detail-accordion">
        <div class="detail-acc-item">
          <button class="detail-acc-head" onclick="toggleAcc(this)">
            <span>DELIVERY &amp; RETURNS</span><span>+</span>
          </button>
          <div class="detail-acc-body">Nationwide delivery in 1–3 business days. Free returns within 7 days on unworn items.</div>
        </div>
        <div class="detail-acc-item">
          <button class="detail-acc-head" onclick="toggleAcc(this)">
            <span>PAYMENT</span><span>+</span>
          </button>
          <div class="detail-acc-body">M-Pesa, cash on delivery, and card accepted. Order confirmation sent via WhatsApp.</div>
        </div>
        <div class="detail-acc-item">
          <button class="detail-acc-head" onclick="toggleAcc(this)">
            <span>SIZE GUIDE</span><span>+</span>
          </button>
          <div class="detail-acc-body">Sneakers: EU sizes. Apparel: standard UK sizes. Not sure? Message us on WhatsApp for sizing help.</div>
        </div>
      </div>
    </div>
  `;
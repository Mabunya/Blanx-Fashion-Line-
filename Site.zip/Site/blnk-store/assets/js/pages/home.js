/* HOME — product grid + category filters */
let activeFilter = "all";

function renderHomeGrid() {
  const grid = document.getElementById("productGrid");
  const empty = document.getElementById("gridEmpty");
  const list = activeFilter === "all" ? PRODUCTS : PRODUCTS.filter(p => p.category === activeFilter);

  empty.style.display = list.length ? "none" : "block";
  grid.innerHTML = list.map(p => `
    <article class="product" onclick="openProduct('${p.id}')">
      <div class="product-image">
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ""}
        ${productVisual(p)}
      </div>
      <div class="product-info">
        <div class="product-name">${p.name}</div>
        <div class="product-price">${money(p.price)}</div>
        <div class="product-colors">${p.colors.map(c => `<span class="color-dot" style="background:${c}"></span>`).join("")}</div>
      </div>
    </article>`).join("");
}

function setFilter(f) {
  activeFilter = f;
  document.querySelectorAll(".cat-tab").forEach(t => t.classList.toggle("active", t.dataset.filter === f));
  renderHomeGrid();
}

document.addEventListener("DOMContentLoaded", async () => {
  document.querySelectorAll("[data-filter]").forEach(el =>
    el.addEventListener("click", () => setFilter(el.dataset.filter)));
  await loadProducts();
  renderHomeGrid();
});
